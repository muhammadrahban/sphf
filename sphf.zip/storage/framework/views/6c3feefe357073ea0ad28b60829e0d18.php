<?php $__env->startSection('webcontain'); ?>
    <main>
        <section class="container my-5" style="max-width: 70% !important;">
            <div class="row">
                <div class="col-md-4 px-2">
                    <div class="border border-secondary border-0 border-bottom-1">
                        <h1 class="bg-title"> Filters </h1>
                        <hr style="border-top: 3px solid gray;">
                    </div>
                    <div class="d-flex justify-content-between">
                        <p class="bg-title m-0">Applied Filters</p>
                        <p class="bg-title clear_all" onclick="clear_all_button()"
                            style="border: none; background-color: transparent; cursor: pointer;">Clear all <span
                                style="font-weight: 700; font-size: 18px;">X</span></p>
                    </div>
                    <div class="my-4 p-4" style="background-color: #f6f6f6 !important;">
                        <form action="" method="post" id="clear_all_form">
                            <?php echo csrf_field(); ?>
                            <div class="form-row align-items-center my-2">
                                <div class="col-12">
                                    <label for="keywords" style="font-size: 20px;">Search by Keywords</label>
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-search" aria-hidden="true"></i>
                                            </div>
                                        </div>
                                        <input type="text" class="form-control" id="keywords" name="keywords"
                                            placeholder="Beneficiary Name" value="<?php echo e(@$data['keywords']); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="form-row align-items-center my-2">
                                <div class="col-12">
                                    <label for="location" style="font-size: 20px;">Location</label>
                                    <select class="custom-select mb-3" id="location" name="location"
                                        placeholder="Dadu, karachi">
                                        <option>Select Location</option>
                                        <option value="Dadu" <?php if(@$data['location'] == 'Dadu'): echo 'selected'; endif; ?>>Dadu</option>
                                        <option value="Jati" <?php if(@$data['location'] == 'Jati'): echo 'selected'; endif; ?>>Jati</option>
                                        <option value="Taluka" <?php if(@$data['location'] == 'Taluka'): echo 'selected'; endif; ?>>Taluka</option>
                                        <option value="karachi" <?php if(@$data['location'] == 'karachi'): echo 'selected'; endif; ?>>karachi</option>
                                        <option value="Ghotki" <?php if(@$data['location'] == 'Ghotki'): echo 'selected'; endif; ?>>Ghotki</option>
                                        <option value="Lakhi" <?php if(@$data['location'] == 'Lakhi'): echo 'selected'; endif; ?>>Lakhi</option>
                                    </select>
                                </div>
                            </div>
                            <!-- <div class="form-row align-items-center my-2">
                                    <div class="col-12">
                                        <label for="location" style="font-size: 13px;">Radius around selected destination</label>
                                        <select class="custom-select mb-3" id="location" placeholder="Dadu, Sukkar">
                                            <option selected>Open this select menu</option>
                                            <option value="1">One</option>
                                            <option value="2">Two</option>
                                            <option value="3">Three</option>
                                        </select>
                                    </div>
                                </div> -->
                            <div class="form-row align-items-center my-2">
                                <label for="vulnerability" style="font-size: 20px;">Vulnerability</label>
                                <div class="col-12">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="widow"
                                            value="vulnerability">
                                        <label class="form-check-label" for="widow">Widow</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="Women"
                                            value="vulnerability">
                                        <label class="form-check-label" for="Women">Women</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="Elderly"
                                            value="vulnerability">
                                        <label class="form-check-label" for="Elderly">Elderly</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="Differntly_Abled"
                                            value="vulnerability">
                                        <label class="form-check-label" for="Differntly_Abled">Differntly Abled</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row align-items-center my-2">
                                <div class="col-12">
                                    <label for="gender" style="font-size: 20px;">Gender</label>
                                    <select class="custom-select mb-3" id="gender" name="gender">
                                        <option>Select Gender</option>
                                        <option value="Male" <?php if(@$data['gender'] == 'Male'): echo 'selected'; endif; ?>>Male</option>
                                        <option value="Female" <?php if(@$data['gender'] == 'Female'): echo 'selected'; endif; ?>>Female</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-row align-items-center my-2">
                                <div class="col-12">
                                    <label for="currency" style="font-size: 20px;">Currency</label>
                                    <select class="custom-select mb-3" id="currency">
                                        <option value="pkr">PKR</option>
                                        <option value="usd">USD</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-row align-items-center my-2">
                                <div class="col-12">
                                    <button type="submit" class="btn btn-warning btn-block">Search</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-8 px-2">
                    <div class="d-flex justify-content-end mb-4">
                        <button type="button" class="btn btn-outline-warning mx-2"><i class="fa fa-heart"
                                aria-hidden="true"></i> Your Beneficiaries List &nbsp;&nbsp; <i class="fa fa-arrow-right"
                                aria-hidden="true"></i></button>
                        <a href="<?php echo e(route('web.checkOutList')); ?>" class="btn btn-warning mx-2">Checkout &nbsp;&nbsp; <i
                                class="fa fa-arrow-right" aria-hidden="true"></i></a>
                    </div>
                    <div class="d-flex justify-content-start m-2">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" class="btn btn-outline-warning mx-2"><?php echo e($list); ?> </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="d-flex justify-content-start m-3">
                        <div class="form-check form-check-inline mx-3">
                            <input class="form-check-input" type="checkbox" id="select_all">
                            <label class="form-check-label bg-title" for="select_all"
                                style="font-size: 20px; color: #878787;">Select All</label>
                        </div>
                        <div class="d-flex mx-3">
                            <i class="fa fa-user" style="font-size: 2.73em;margin-top: 5px;margin-right: 5px;"
                                aria-hidden="true"></i>
                            <div class="d-flex flex-column">
                                <p class="m-0">Persons</p>
                                <p style="font-size: 20px; font-weight: 600; margin: 0;"><?php echo e($count); ?></p>
                            </div>
                        </div>
                        <div class="d-flex mx-3">
                            <i class="fa fa-home" style="font-size: 2.73em;margin-top: 5px;margin-right: 5px;"
                                aria-hidden="true"></i>
                            <div class="d-flex flex-column">
                                <p class="m-0">Homes</p>
                                <p style="font-size: 20px; font-weight: 600; margin: 0;"><?php echo e($count); ?></p>
                            </div>
                        </div>
                        <div class="d-flex ml-auto w-40">
                            <label class="w-50" for="sort_by">Sort by : </label>
                            <select class="form-control" id="sort_by">
                                <option value="most_relevant">Most Relevant</option>
                                <option value="show_all">Show All</option>
                            </select>
                        </div>
                    </div>
                    <div class="mx-3 my-4">
                        <?php $__currentLoopData = $foundItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between my-3 align-items-center searchable-item">
                                <input class="mx-3" type="checkbox" class="heart" />
                                
                                <img src="<?php echo e(asset('images/users/1.jpg')); ?>" width="70" height="70"
                                    class="rounded-circle">
                                <div class="d-flex flex-column mx-3">
                                    <h5 class="bg-title benf_name"><?php echo e($item['BenfName']); ?></h5>
                                    <div class="d-flex" style="font-size: 18px;">
                                        <p class="text-primary m-0 mr-4"><i class="fa fa-bars" aria-hidden="true"></i>
                                            Widow</p>
                                        <p class="text-secondary m-0 mx-4"><i class="fa fa-map-marker"
                                                aria-hidden="true"></i> <?php echo e($item['Tehsil']); ?></p>
                                        <p class="text-secondary m-0 mx-4"><i class="fa fa-btc" aria-hidden="true"></i>
                                            PKR 300,000</p>
                                    </div>
                                    <p class="m-0 w-auto rounded text-left px-2 my-3" style="background-color: #ececec;">
                                        <?php echo e($item['Message']); ?></p>
                                </div>
                                <div class="ml-auto">
                                    <div class="d-flex flex-column">
                                        <p class="bg-title text-success text-right m-0">ID: <?php echo e($item['BenfId']); ?></p>
                                        <button type="button" class="btn btn-info mt-4 px-4 py-2 text-center">View
                                            Profile</button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </section>
    </main>

    <script>
        function clear_all_button() {
            $('#clear_all_form').find(':input').each(function() {
                if (this.type !== 'submit' && this.type !== 'button' && this.type !== 'hidden') {
                    $(this).val('');
                }
            });
        }

        $('#select_all').click(function(){

            var isChecked = this.checked;
            $('.searchable-item input[type="checkbox"]').each(function() {
                this.checked = isChecked;
            });

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sphf\resources\views/web/filter/view.blade.php ENDPATH**/ ?>